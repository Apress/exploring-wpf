﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.IO;
using System.Windows.Media.Imaging;
using System.Drawing;

namespace WpfApp1
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        Stream SelectedFile;
        string SelectedFileExtension;
        private void SelectFileBt_Click(object sender, RoutedEventArgs e)
        {
            var dialog = new Microsoft.Win32.OpenFileDialog();
            dialog.InitialDirectory = "D:\\test";
            if (dialog.ShowDialog() == true)
            {
                ProgressBar.IsIndeterminate = true;
                string tempname = dialog.FileName;

                var parsedname = tempname.Split('.');
                SelectedFileExtension = parsedname[1];
                OrginalName.Content = (parsedname[0].Split('\\')).Last();
                SelectedFile = dialog.OpenFile();
                 
                System.Drawing.Image image = System.Drawing.Image.FromStream(SelectedFile);
                NewName.Content = image.Width + "x" + image.Height+ "T" + DateTime.UtcNow.Ticks.ToString();
                image.Dispose();
                ProgressBar.IsIndeterminate = false;
            }
        }

        private void SaveFileBt_Click(object sender, RoutedEventArgs e)
        { 
                var dialog = new Microsoft.Win32.SaveFileDialog();
                dialog.InitialDirectory = "D:\\test";
                dialog.Title = "Save as";
                dialog.FileName = NewName.Content.ToString()+"."+SelectedFileExtension; 

                if (dialog.ShowDialog() == true)
                {
                    string path = dialog.FileName;
                    SelectedFile.Seek(0, SeekOrigin.Begin);
                    byte[] bytes = new byte[SelectedFile.Length + 10];
                    int numBytesToRead = (int)SelectedFile.Length;
                    int numBytesRead = 0;
                    do
                    {
                        int n = SelectedFile.Read(bytes, numBytesRead, 10);
                        numBytesRead += n;
                        numBytesToRead -= n;
                    } while (numBytesToRead > 0);
                    SelectedFile.Close(); 

                    System.IO.File.WriteAllBytes(path, bytes); 
                } 
        }
    }
}
