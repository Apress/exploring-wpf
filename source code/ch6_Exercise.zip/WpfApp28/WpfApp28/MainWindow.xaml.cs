﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfApp28
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();

            slider_brushsize.Value = 10;
            slider_brushsize.Minimum = 2;
            slider_brushsize.Maximum = 30;
        }

        

        private void canv_MouseMove(object sender, MouseEventArgs e)
        {
            if (e.LeftButton == MouseButtonState.Pressed)
            {
               
                if (rb_brushtype1.IsChecked == true)
                {
                    Line line = new Line();
                    line.Stroke = new SolidColorBrush(Color.FromRgb(Convert.ToByte(tb_color_r.Text), Convert.ToByte(tb_color_g.Text), Convert.ToByte(tb_color_b.Text)));
                    line.X1 = e.GetPosition(canv).X;
                    line.Y1 = e.GetPosition(canv).Y;
                    line.X2 = e.GetPosition(canv).X + slider_brushsize.Value;
                    line.Y2 = e.GetPosition(canv).Y + slider_brushsize.Value;

                    canv.Children.Add(line);
                }

                if (rb_brushtype2.IsChecked == true)
                {
                    Ellipse ellipse = new Ellipse();
                    ellipse.Stroke = new SolidColorBrush(Color.FromRgb(Convert.ToByte(tb_color_r.Text), Convert.ToByte(tb_color_g.Text), Convert.ToByte(tb_color_b.Text)));
                    ellipse.Margin = new Thickness(e.GetPosition(canv).X, e.GetPosition(canv).Y, e.GetPosition(canv).X + 1, e.GetPosition(canv).Y + 1);
                    ellipse.Height = slider_brushsize.Value;
                    ellipse.Width = slider_brushsize.Value;
                    ellipse.Fill = new SolidColorBrush(Color.FromRgb(Convert.ToByte(tb_color_r.Text), Convert.ToByte(tb_color_g.Text), Convert.ToByte(tb_color_b.Text)));

                    canv.Children.Add(ellipse);
                }
                    
            }
        }

        private void bt_clear_Click(object sender, RoutedEventArgs e)
        {
            if (MessageBox.Show("Are you sure?", "Clearing canvas", MessageBoxButton.YesNo) == MessageBoxResult.Yes)
            {
                canv.Children.Clear();
            }
            
        }
         

        private void bt_reset_Click(object sender, RoutedEventArgs e)
        {
            if (MessageBox.Show("Are you sure? This will clear the canvas and reset your choices to default.", "Clearing canvas", MessageBoxButton.YesNo) == MessageBoxResult.Yes)
            {
                canv.Children.Clear();
                rb_brushtype2.IsChecked = true;
                slider_brushsize.Value = 10;
                tb_color_r.Text = "0";
                tb_color_g.Text = "0";
                tb_color_b.Text = "0";
            }
        }


        protected override void OnClosing(CancelEventArgs e)
        {
            if (canv.Children.Count > 0)
            {
                if (MessageBox.Show("Your canvas is not empty. Are you sure you want to leave?", "Exit", MessageBoxButton.OKCancel) == MessageBoxResult.Cancel)
                {
                    e.Cancel = true;
                }
            }
            
            base.OnClosing(e);
        }
    }
}
