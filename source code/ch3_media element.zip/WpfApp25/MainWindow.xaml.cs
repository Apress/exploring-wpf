﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfApp25
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            soundslider.Minimum = 0;
            soundslider.Maximum = 1000;
            soundslider.Value = 30;
             
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
             
            md.Source =new System.Uri("G:\\test\\Chatbot_Live.in.action.mp4");
            
            md.Play();
            while (md.NaturalDuration.HasTimeSpan == false)
            {
                
            }
            timeslider.Maximum = md.NaturalDuration.TimeSpan.TotalSeconds;
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            md.Stop();
        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            md.Pause();
        }

        private void Button_Click_3(object sender, RoutedEventArgs e)
        {
            md.Play();

        }

        private void Soundslider_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
           
            md.Volume = e.NewValue;
        }

        private void Timeslider_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            md.Pause();
            md.Position = new TimeSpan(0,0,Convert.ToInt32(Math.Round(e.NewValue)));
            timelabel.Content = md.Position.TotalSeconds;
            md.Play();
        }
    }
}
