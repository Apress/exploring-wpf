﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfApp1
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        protected override void OnClosing(CancelEventArgs e)
        {
            if (namebox.Text.Length > 0 || biobox.Text.Length > 0)
            {
                if (MessageBox.Show("Are you sure you want to leave?","Exit notice",MessageBoxButton.YesNo) == MessageBoxResult.No)
                {
                    e.Cancel = true;
                }
            }
            base.OnClosing(e);
        }

        private void namebox_MouseEnter(object sender, MouseEventArgs e)
        {
            labelalert1.Visibility = Visibility.Visible;
        }

        private void namebox_MouseLeave(object sender, MouseEventArgs e)
        {
            labelalert1.Visibility = Visibility.Collapsed;
        }

        private void biobox_MouseEnter(object sender, MouseEventArgs e)
        {
            labelalert2.Visibility = Visibility.Visible;
        }

        private void biobox_MouseLeave(object sender, MouseEventArgs e)
        {
            labelalert2.Visibility = Visibility.Collapsed;
        }
    }
}
