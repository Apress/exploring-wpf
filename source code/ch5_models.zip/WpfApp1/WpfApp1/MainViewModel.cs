﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;

namespace WpfApp1
{
    public class MainViewModel : INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler PropertyChanged;

        private ICommand _clickCommand;
        public ObservableCollection<TestModel> TestViewData { get; set; } = new ObservableCollection<TestModel>();
        public string InputItem1 { get; set; }
        public string InputItem2 { get; set; }
        public string InputItem3 { get; set; }
        public ICommand ClickCommand
        {
            get
            {
                return _clickCommand ?? (_clickCommand = new CommandHandler(() => InsertAction(), () => CanExecute));
            }
        }
        public bool CanExecute
        {
            get
            {
                return true;
            }
        }

        public void InsertAction()
        {
            TestViewData.Add(new TestModel() { item1 = InputItem1, item2 = InputItem2, item3 = InputItem3 }); 
            PropertyChanged.Invoke(this, new PropertyChangedEventArgs("TestViewData"));
        }

    }

    public class CommandHandler : ICommand
    {
        private Action _action;
        private Func<bool> _canExecute;


        public CommandHandler(Action action, Func<bool> canExecute)
        {
            _action = action;
            _canExecute = canExecute;
        }


        public event EventHandler CanExecuteChanged
        {
            add { CommandManager.RequerySuggested += value; }
            remove { CommandManager.RequerySuggested -= value; }
        }


        public bool CanExecute(object parameter)
        {
            return _canExecute.Invoke();
        }

        public void Execute(object parameter)
        {
            _action();
        }
    }
}
