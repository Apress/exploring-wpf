﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WpfApp1
{
    public class TestModel
    {
        public string item1 { get; set; }
        public string item2 { get; set; }
        public string item3 { get; set; }
    }
}
