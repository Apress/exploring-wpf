﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfApp31
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Line_bt_Click(object sender, RoutedEventArgs e)
        {
            Line ln = new Line();
            ln.Stroke = SystemColors.GrayTextBrush;
            ln.X1 = 0;
            ln.Y1 = 0;
            ln.X2 = 300;
            ln.Y2 = 200;
            cnv.Children.Add(ln);
        }

        private void Circle_bt_Click(object sender, RoutedEventArgs e)
        {
           Ellipse el = new Ellipse();
            el.Stroke = SystemColors.HighlightBrush;
            el.Width = 100;
            el.Height = 100;
            cnv.Children.Add(el);
        }

        private void Square_bt_Click(object sender, RoutedEventArgs e)
        {
            Rectangle sq = new Rectangle();
            sq.Stroke = SystemColors.HighlightBrush;
            sq.Width = 100;
            sq.Height = 100;
            sq.Margin = new Thickness(100, 0, 0, 0);
            cnv.Children.Add(sq);
        }

       
    }
}
