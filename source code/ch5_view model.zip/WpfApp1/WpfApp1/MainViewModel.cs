﻿

using System;
using System.ComponentModel;
using System.Windows.Input;

namespace WpfApp1
{
    public class MainViewModel : INotifyPropertyChanged 
    {
        public event PropertyChangedEventHandler PropertyChanged;

        private ICommand _clickCommand;
        public string PropertyForLabel { get; set; } = "test";
        public ICommand ClickCommand
        {
            get
            {
                return _clickCommand ?? (_clickCommand = new CommandHandler(() => TestAction(), () => CanExecute));
            }
        }
        public bool CanExecute
        {
            get
            { 
                return true;
            }
        }

        public void TestAction()
        {
            
            PropertyForLabel = DateTime.UtcNow.ToString();
            PropertyChanged.Invoke(this, new PropertyChangedEventArgs("PropertyForLabel"));
        }

    }

    public class CommandHandler : ICommand
    {
        private Action _action;
        private Func<bool> _canExecute;

   
        public CommandHandler(Action action, Func<bool> canExecute)
        {
            _action = action;
            _canExecute = canExecute;
        }

       
        public event EventHandler CanExecuteChanged
        {
            add { CommandManager.RequerySuggested += value; }
            remove { CommandManager.RequerySuggested -= value; }
        }

        
        public bool CanExecute(object parameter)
        {
            return _canExecute.Invoke();
        }

        public void Execute(object parameter)
        {
            _action();
        }
    }
}
