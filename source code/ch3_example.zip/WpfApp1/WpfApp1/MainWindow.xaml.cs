﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfApp1
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void AddVideoButton_Click(object sender, RoutedEventArgs e)
        {
            VideoList.Items.Add(new ListItemModel() { Description = Vd_descriptionbox.Text, Url = Vd_urlbox.Text });
        }

        private void AddImageButton_Click(object sender, RoutedEventArgs e)
        {
            ImageList.Items.Add(new ListItemModel() { Description = Img_descriptionbox.Text, Url = Img_urlbox.Text });
        }

        private void VideoList_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            VideoWindow win = new VideoWindow(((ListItemModel)((ListView)sender).SelectedItem).Url);
            win.Show();
        }

        private void ImageList_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            ImageWindow win = new ImageWindow(((ListItemModel)((ListView)sender).SelectedItem).Url);
            win.Show();
        }
    }
}
