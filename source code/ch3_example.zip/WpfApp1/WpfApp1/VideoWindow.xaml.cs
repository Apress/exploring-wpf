﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace WpfApp1
{
    /// <summary>
    /// Interaction logic for VideoWindow.xaml
    /// </summary>
    public partial class VideoWindow : Window
    {
        private readonly string _urltodisplay;
        public VideoWindow(string urltodisplay)
        {
            
            InitializeComponent();
            _urltodisplay = urltodisplay;
        }

        private void PlayBt_Click(object sender, RoutedEventArgs e)
        {
            VideoPlayer.Source = new Uri(_urltodisplay);
            VideoPlayer.Play();
        }
    }
}
