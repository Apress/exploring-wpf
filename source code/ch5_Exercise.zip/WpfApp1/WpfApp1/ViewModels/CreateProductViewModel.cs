﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;

namespace WpfApp1.ViewModels
{
    class CreateProductViewModel : INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler PropertyChanged;

        private ICommand _clickCommand;

        public  ProductHandler.Product Product { get; set; } = new ProductHandler.Product();

        public ICommand ClickCommand
        {
            get
            {
                return _clickCommand ?? (_clickCommand = new CommandHandler(async () => {
                    if (await ProductHandler.WriteNewProductAsync(Product)){
                        MessageBox.Show("Product added");
                        Product = new ProductHandler.Product();
                        PropertyChanged.Invoke(this, new PropertyChangedEventArgs("Product"));
                    }
                    else
                    {
                        MessageBox.Show("Something went wrong");
                    }
                }, () => CanExecute));
            }
        }
        public bool CanExecute
        {
            get
            {
                return true;
            }
        } 
    }

    
}
