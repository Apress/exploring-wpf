﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;

namespace WpfApp1.ViewModels
{
    class ProductViewViewModel : INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler PropertyChanged;

        private ICommand _clickCommand;

        public  List<ProductHandler.Product> Products { get; set; }
        public ProductHandler.Product DisplayedProduct { get; set; } = new ProductHandler.Product();
         
        public ICommand ClickCommand
        {
            get
            {
                return _clickCommand ?? (_clickCommand = new CommandHandler(async () => {
                    try
                    {
                        if (Products == null)
                        {
                            Products = await ProductHandler.OpenProductsAsync();
                        }
                        
                        DisplayedProduct = Products.Find(p => p.EAN == DisplayedProduct.EAN);
                        PropertyChanged.Invoke(this, new PropertyChangedEventArgs("DisplayedProduct"));
                    }
                    catch (Exception e)
                    {
                        MessageBox.Show(e.Message);
                    }
                }, () => CanExecute));
            }
        }
        public bool CanExecute
        {
            get
            {
                return true;
            }
        } 
    }
}
