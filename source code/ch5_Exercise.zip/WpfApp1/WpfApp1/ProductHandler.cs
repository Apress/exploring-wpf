﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using Newtonsoft.Json;

namespace WpfApp1
{
    class ProductHandler
    {
        public class Product
        {
           public string EAN { get; set; }
           public int Price { get; set; }
           public int MaximumDiscount { get; set; }
           public string Title { get; set; }
           public string Description { get; set; }
           public double Quantity { get; set; }
        }
        public static async Task<List<Product>> OpenProductsAsync()
        {
            try
            {
                FileStream fl = File.OpenRead(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData) + "\\producthandler\\products.pmapp");
                byte[] bt = new byte[fl.Length];
                await fl.ReadAsync(bt);
                await fl.DisposeAsync();
                var data = JsonConvert.DeserializeObject<List<Product>>(System.Text.Encoding.UTF8.GetString(bt));
                return data;
            }
            catch (Exception e)
            {
                return null;
            }
        }

        public static async Task<bool> WriteNewProductAsync(Product product)
        {
            List<Product> current = new List<Product>();
            try
            {
                FileStream fl = File.Create(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData) + "\\producthandler\\products.pmapp");
                byte[] bt = new byte[fl.Length];
                await fl.ReadAsync(bt);
                await fl.DisposeAsync();
                if (bt.Length != 0)
                {
                    current = JsonConvert.DeserializeObject<List<Product>>(System.Text.Encoding.UTF8.GetString(bt));
                }
            }
            catch  
            { 
            }

            try
            { 
                current.Add(product);
                FileStream flwrite = File.Create(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData) + "\\producthandler\\products.pmapp");
                flwrite.Write(System.Text.Encoding.UTF8.GetBytes(JsonConvert.SerializeObject(current)));
                return true;
            }
            catch (Exception e)
            {
                return false;
            }
        }
    }
}
