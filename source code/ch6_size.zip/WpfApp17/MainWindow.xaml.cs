﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfApp17
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Bt_mixed_Click(object sender, RoutedEventArgs e)
        {
            Window win = new mixedwindow();
            win.Show();
        }

        private void Bt_fixed_Click(object sender, RoutedEventArgs e)
        {
            Window win = new fixedsizewindow();
            win.Show();
        }

        private void Bt_scroll_Click(object sender, RoutedEventArgs e)
        {
            Window win = new scrollwindow();
            win.Show();
        }

        private void Bt_viewbox_Click(object sender, RoutedEventArgs e)
        {
            Window win = new viewboxwindow();
            win.Show();
        }
    }
}
