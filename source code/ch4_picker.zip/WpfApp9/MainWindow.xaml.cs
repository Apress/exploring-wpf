﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes; 
namespace WpfApp9
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        System.IO.Stream filestr;
        string file_ext = "";
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Btpick_Click(object sender, RoutedEventArgs e)
        {
            var dialog = new Microsoft.Win32.OpenFileDialog();
            dialog.InitialDirectory = "G:\\test";
            if (dialog.ShowDialog() == true)
            {
                string tempname = dialog.FileName;
                var parsedname = tempname.Split('.');
                file_ext = parsedname[1];
                filestr = dialog.OpenFile();
            }
        }

        private void Btsave_Click(object sender, RoutedEventArgs e)
        {
            var dialog = new Microsoft.Win32.SaveFileDialog();
            dialog.InitialDirectory = "G:\\test";  
            dialog.Title = "Save as";  
            dialog.FileName = "test";
            
            if (dialog.ShowDialog() == true)
            {
                string path = dialog.FileName; 
                byte[] bytes = new byte[filestr.Length + 10];
                int numBytesToRead = (int)filestr.Length;
                int numBytesRead = 0;
                do
                { 
                    int n = filestr.Read(bytes, numBytesRead, 10);
                    numBytesRead += n;
                    numBytesToRead -= n;
                } while (numBytesToRead > 0);
                filestr.Close();

                System.IO.File.WriteAllBytes(path+"."+file_ext, bytes);
 
                  
            }
        }
    }
}
