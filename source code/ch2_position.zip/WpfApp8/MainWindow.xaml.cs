﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfApp8
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            grd1.MouseDown += Grd1_MouseDown;
            //grd1.MouseEnter += Grd1_MouseEnter;
            grd1.MouseMove += Grd1_MouseMove;
            grd1.MouseLeave += Grd1_MouseLeave;
        }

        private void Grd1_MouseMove(object sender, MouseEventArgs e)
        {
            tb1.Text = e.GetPosition(grd1).X.ToString() + ":" + e.GetPosition(grd1).Y.ToString();
        }

        private void Grd1_MouseLeave(object sender, MouseEventArgs e)
        {
            MessageBox.Show(e.GetPosition(grd1).X.ToString() + ":" + e.GetPosition(grd1).Y.ToString());
        }

        private void Grd1_MouseEnter(object sender, MouseEventArgs e)
        {
            MessageBox.Show(e.GetPosition(grd1).X.ToString() + ":" + e.GetPosition(grd1).Y.ToString());
        }

        private void Grd1_MouseDown(object sender, MouseButtonEventArgs e)
        {
            MessageBox.Show(e.GetPosition(grd1).X.ToString() + ":" + e.GetPosition(grd1).Y.ToString());
        }
    }
}
