﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfApp1
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void bt_copy_Click(object sender, RoutedEventArgs e)
        {
            Clipboard.SetText(tb_password.Text);
        }

        private void bt_generate_Click(object sender, RoutedEventArgs e)
        {
            var rnd = new Random();
            tb_password.Text = rnd.Next(20000,30000).ToString();
        }

        private void bt_submit_Click(object sender, RoutedEventArgs e)
        {
            if (tb_password.Text.Length < 4)
            {
                MessageBox.Show("Password needs to be at least 4 characters.", "Password error");
                return;
            }

            //submit
        }
    }
}
