﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfApp1
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            GenerateElements();
        }

        void GenerateElements()
        {
            Button bt = new Button();
            //properties of button
            bt.Content = "Click to test";
            bt.Margin = new Thickness(10, 10, 0, 0);
            bt.HorizontalAlignment = HorizontalAlignment.Left;
            bt.VerticalAlignment = VerticalAlignment.Top;
            bt.Height = 30;
            bt.Width = 200;
            bt.Click += Bt_Click;


            TextBox tb = new TextBox();
            //properties of text box
            tb.Name = "tb1";
            tb.Margin = new Thickness(10, 60, 0, 0);
            tb.HorizontalAlignment = HorizontalAlignment.Left;
            tb.VerticalAlignment = VerticalAlignment.Top;
            tb.Height = 30;
            tb.Width = 200;

            maingrid.Children.Add(bt);
             maingrid.Children.Add(tb);
        }

        private void Bt_Click(object sender, RoutedEventArgs e)
        {
            var tb = maingrid.Children.OfType<TextBox>().First(Child => Child.Name == "tb1");
            MessageBox.Show(tb.Text);
        }
    }
}
