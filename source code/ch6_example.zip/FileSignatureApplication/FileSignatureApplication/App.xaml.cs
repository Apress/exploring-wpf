﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;

namespace FileSignatureApplication
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
        public static SaveFileModel currentsavedata = new SaveFileModel();

        public static string initialdirectory = "D:\\test";
        protected override void OnStartup(StartupEventArgs e)
        {
            

            var formatter = new System.Runtime.Serialization.Formatters.Binary.BinaryFormatter();

            FileStream savefile = File.OpenRead(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments) + "\\savefile.fsappsf");
             
            var savedata =  formatter.Deserialize(savefile);
            currentsavedata = (SaveFileModel)savedata;
             
            base.OnStartup(e);
        }
    }
}
