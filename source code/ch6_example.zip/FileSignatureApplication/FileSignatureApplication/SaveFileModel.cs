﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FileSignatureApplication
{
    [Serializable]
    public class SaveFileModel
    {
        public  DateTime LastSaved { get; set; }
        public List<byte[]> Signatures { get; set; } = new List<byte[]>();
    }
}
