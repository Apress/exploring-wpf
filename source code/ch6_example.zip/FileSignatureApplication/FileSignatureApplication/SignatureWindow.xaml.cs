﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

using System.IO;
using System.ComponentModel;

namespace FileSignatureApplication
{
    /// <summary>
    /// Interaction logic for SignatureWindow.xaml
    /// </summary>
    public partial class SignatureWindow : Window
    {
        public SignatureWindow()
        {
            InitializeComponent();
            PickFile_button.Click += PickFile;
            GenerateSignature_button.Click += CreateSignature;
            Copy_button.Click += CopyToClipboard;
            OpenFile_button.Click += OpenFile;
        }


        byte[] Signature;
        public async void CreateSignature(object obj, RoutedEventArgs e)
        {
            ((Button)obj).IsEnabled = false;
            MainProgressBar.IsIndeterminate = true;
            await Task.Run(() =>
            {
                var hasher = new System.Security.Cryptography.HMACSHA512(SelectedFileBt);


                Signature = hasher.ComputeHash(SelectedFileBt);

                Dispatcher.Invoke(() => {
                    SaveRecord();
                    OutputBox.Text = Convert.ToBase64String(Signature);
                    ((Button)obj).IsEnabled = true;

                    MainProgressBar.IsIndeterminate = false;
                });
               
            });

            

        }


        
        byte[] SelectedFileBt;
        string FilePath;
        private  void PickFile(object obj, RoutedEventArgs e)
        {
            var dialog = new Microsoft.Win32.OpenFileDialog();
            dialog.InitialDirectory = App.initialdirectory;
            if (dialog.ShowDialog() == true)
            {
                string tempname = dialog.FileName;

                var parsedname = tempname.Split('.');


                FileStream selectedfile = (FileStream)dialog.OpenFile();

                MemoryStream mstr = new MemoryStream();
                selectedfile.CopyTo(mstr);
                SelectedFileBt = mstr.ToArray();


                FilePath = dialog.FileName;
                label_filename.Content =  (parsedname[0].Split('\\')).Last();

                if (selectedfile.Length < 1000000)
                {
                    label_filesize.Content = Math.Round(Convert.ToDouble(selectedfile.Length) / 1024, 0).ToString() + "Kb";
                }

                if (selectedfile.Length >= 1000000 && selectedfile.Length < 10000000)
                {
                    label_filesize.Content = Math.Round(Convert.ToDouble(selectedfile.Length )/ 1024 / 1024,2).ToString() + "Mb";
                }

                if (selectedfile.Length >= 10000000)
                {
                    label_filesize.Content = Math.Round(Convert.ToDouble(selectedfile.Length) / 1024 / 1024 / 1024,2).ToString() + "Gb";
                }

                label_filetype.Content = parsedname[1];

                InitialGrid.Visibility = Visibility.Collapsed;
                PrimaryGrid.Visibility = Visibility.Visible;


                
            }
        }

        

        public void SaveRecord()
        {
           var formatter = new System.Runtime.Serialization.Formatters.Binary.BinaryFormatter();
            FileStream savefile = File.Create(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments) + "\\savefile.fsappsf");
            App.currentsavedata.Signatures.Add(Signature);
            formatter.Serialize(savefile, App.currentsavedata);
        }

        public void OpenFile(object obj, RoutedEventArgs e)
        {
            System.Diagnostics.Process.Start(FilePath);
        }


        public  void CopyToClipboard(object obj, RoutedEventArgs e)
        {
            Clipboard.SetText(OutputBox.Text);
        }


        protected override void OnClosing(CancelEventArgs e)
        { 
            if (MainProgressBar.IsIndeterminate)
            {
                var msg = MessageBox.Show("Signature is being created, are you sure you want to exit?","ready to leave?",MessageBoxButton.OKCancel);

                if (msg == MessageBoxResult.Cancel)
                {
                    e.Cancel = true;
                }
            }
            base.OnClosing(e);
        }
    }
}
