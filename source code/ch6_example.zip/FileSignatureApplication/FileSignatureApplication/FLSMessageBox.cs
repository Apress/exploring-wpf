﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;

namespace FileSignatureApplication
{
    public class FLSMessageBox
    {
        public string OutputText { get; private set; }
        public int OptionClicked { get; private set; }
        private int MessageType;
        public bool InputOK { get; set; }

        private string msg = "";
        private string cp = "";

        /// <summary>
        /// 
        /// </summary>
        /// <param name="message"></param>
        /// <param name="caption"></param>
        /// <param name="type">1 - OK, 2 - Yes/No, 3 - Yes/No/Cancel, 4 - OK/Cancel</param>
        public FLSMessageBox(string message, string caption, int type)
        {
            msg = message;
            cp = caption;
            MessageType = type;
        }
        Window win = new Window();
        TextBox tb = new TextBox();
        public int Show()
        {
            Grid maingrid = new Grid();
            win.Content = maingrid;
            win.Height = 150;
            win.Width = 300;
            win.ResizeMode = ResizeMode.CanMinimize;
            win.Title = cp;

            //inputbox 
            tb.Height = 25;
            tb.Width = 160;
            tb.HorizontalAlignment = HorizontalAlignment.Left;
            tb.VerticalAlignment = VerticalAlignment.Center;
            tb.Margin = new Thickness(0, 0, 0, 0);

            //label
            Label lb = new Label();
            lb.Height = 25;
            lb.Width = 160;
            lb.HorizontalAlignment = HorizontalAlignment.Left;
            lb.VerticalAlignment = VerticalAlignment.Top;
            lb.Margin = new Thickness(0, 0, 0, 0);
            lb.Content = msg;

            //okay
            Button bt_okay = new Button();
            bt_okay.Content = "Ok";
            bt_okay.Height = 25;
            bt_okay.Width = 40;
            bt_okay.HorizontalAlignment = HorizontalAlignment.Left;
            bt_okay.VerticalAlignment = VerticalAlignment.Bottom;
            bt_okay.Margin = new Thickness(0, 0, 0, 0);
            bt_okay.Click += Bt_okay_Click;

            //yes
            Button bt_yes = new Button();
            bt_yes.Content = "Yes";
            bt_yes.Height = 25;
            bt_yes.Width = 40;
            bt_yes.HorizontalAlignment = HorizontalAlignment.Left;
            bt_yes.VerticalAlignment = VerticalAlignment.Bottom;
            bt_yes.Margin = new Thickness(40, 0, 0, 0);
            bt_yes.Click += Bt_yes_Click;

            //no
            Button bt_no = new Button();
            bt_no.Content = "No";
            bt_no.Height = 25;
            bt_no.Width = 40;
            bt_no.HorizontalAlignment = HorizontalAlignment.Left;
            bt_no.VerticalAlignment = VerticalAlignment.Bottom;
            bt_no.Margin = new Thickness(80, 0, 0, 0);
            bt_no.Click += Bt_no_Click;

            //cancel
            Button bt_cancel = new Button();
            bt_cancel.Content = "Cancel";
            bt_cancel.Height = 25;
            bt_cancel.Width = 40;
            bt_cancel.HorizontalAlignment = HorizontalAlignment.Left;
            bt_cancel.VerticalAlignment = VerticalAlignment.Bottom;
            bt_cancel.Margin = new Thickness(120, 0, 0, 0);
            bt_cancel.Click += Bt_cancel_Click;
             
            switch (MessageType)
            {
                case 1:
                    maingrid.Children.Add(bt_okay);
                    break;
                case 2:
                    maingrid.Children.Add(bt_no);
                    maingrid.Children.Add(bt_yes);
                    break;
                case 3:
                    maingrid.Children.Add(bt_no);
                    maingrid.Children.Add(bt_yes);
                    maingrid.Children.Add(bt_cancel);
                    break;
                case 4:
                    maingrid.Children.Add(bt_okay);
                    maingrid.Children.Add(bt_cancel);
                    break;
                default:
                    break;
            }

            maingrid.Children.Add(lb);
            if (InputOK)
            {
                maingrid.Children.Add(tb);
            }
            win.ShowDialog();
            return OptionClicked;
        }

        private void Bt_okay_Click(object sender, RoutedEventArgs e)
        {
            if (InputOK)
            {
                OutputText = tb.Text;
            }
            OptionClicked = 1;
            win.Close();
        }

        private void Bt_yes_Click(object sender, RoutedEventArgs e)
        {
            if (InputOK)
            {
                OutputText = tb.Text;
            }
            OptionClicked = 2;
            win.Close();
        }

        private void Bt_no_Click(object sender, RoutedEventArgs e)
        {
            if (InputOK)
            {
                OutputText = tb.Text;
            }
            OptionClicked = 3;
            win.Close();
        }

        private void Bt_cancel_Click(object sender, RoutedEventArgs e)
        {  
            OptionClicked = 4;
            win.Close();
        }
    }
}
