﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace FileSignatureApplication
{
    /// <summary>
    /// Interaction logic for VerificationWindow.xaml
    /// </summary>
    public partial class VerificationWindow : Window
    {
        public VerificationWindow()
        {
            InitializeComponent();
        }

        

        private async void PickFile_button_Click(object sender, RoutedEventArgs e)
        {
            initialgrid.Visibility = Visibility.Hidden;
            MainProgressBar.IsIndeterminate = true;
            MainProgressBar.Visibility = Visibility.Visible;

            var dialog = new Microsoft.Win32.OpenFileDialog();
            dialog.InitialDirectory = "D:\\test";
            if (dialog.ShowDialog() == true)
            {
                string tempname = dialog.FileName;
                FileStream selectedfile = (FileStream)dialog.OpenFile();

                await Task.Run(() =>
                {
                    MemoryStream mstr = new MemoryStream();
                    selectedfile.CopyTo(mstr);
                    byte[] SelectedFileBt = mstr.ToArray();

                    var hasher = new System.Security.Cryptography.HMACSHA512(SelectedFileBt);

                    byte[] signature = hasher.ComputeHash(SelectedFileBt);

                    Dispatcher.Invoke(() => {
                        if (App.currentsavedata.Signatures.Exists(x => Convert.ToBase64String(x) ==  Convert.ToBase64String(signature)))
                        {
                            validlabel.Visibility = Visibility.Visible;
                            notvalidlabel.Visibility = Visibility.Hidden;
                        }
                        else
                        {
                            notvalidlabel.Visibility = Visibility.Visible;
                            validlabel.Visibility = Visibility.Hidden;
                        }
                        MainProgressBar.IsIndeterminate = false;
                        MainProgressBar.Visibility = Visibility.Hidden;
                        resultgrid.Visibility = Visibility.Visible;
                    });

                });
            }
        }
    }
}
