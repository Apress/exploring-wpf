﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Net.Http.Json;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;

namespace WpfApp1.ViewModels
{
    class VerificationViewModel 
    {  
        private ICommand _clickCommand;

        public SharedDataModels.CountryModel Country { get; set; } = new SharedDataModels.CountryModel();

        public ICommand ClickCommand_verify
        {
            get
            {
                return _clickCommand ?? (_clickCommand = new CommandHandler(async () => {
                    try
                    {
                        bool response = await (await App.client.PostAsJsonAsync("/details/verify", Country)).Content.ReadFromJsonAsync<bool>();
                        if (response)
                        {
                            MessageBox.Show("Success");
                        }
                        else
                        {
                            MessageBox.Show("Failed");
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.Message);
                    }
                }, () => CanExecute));
            }
        }

        
        public bool CanExecute
        {
            get
            {
                return true;
            }
        }


    }
}
