﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Net.Http.Json;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;

namespace WpfApp1.ViewModels
{
    class EncoderViewModel : INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler PropertyChanged;

        private ICommand _clickCommand1;
        private ICommand _clickCommand2;


        public string Name { get; set; }
        public string Code { get; set; }

        public ICommand ClickCommand_toname
        {
            get
            {
                return _clickCommand1 ?? (_clickCommand1 = new CommandHandler(async () => {
                    try
                    {
                        Name = await App.client.GetFromJsonAsync<string>("/encoder/codetoname?code=" + Code);
                        PropertyChanged.Invoke(this, new PropertyChangedEventArgs("Name"));
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.Message);
                    }
                }, () => CanExecute));
            }
        }

        public ICommand ClickCommand_tocode
        {
            get
            {
                return _clickCommand2 ?? (_clickCommand2 = new CommandHandler(async () => {
                    try
                    {
                        Code = await App.client.GetFromJsonAsync<string>("/encoder/nametocode?name=" + Name);
                    PropertyChanged.Invoke(this, new PropertyChangedEventArgs("Code"));
                    }
                    catch (Exception ex)
                    {
                    MessageBox.Show(ex.Message);
                    }
            }, () => CanExecute));
            }
        }
        public bool CanExecute
        {
            get
            {
                return true;
            }
        }
         

    }

    
}
