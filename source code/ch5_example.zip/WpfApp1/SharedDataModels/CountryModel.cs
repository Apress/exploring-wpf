﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json.Serialization;
using System.Threading.Tasks;
 
namespace SharedDataModels
{
    public class CountryModel
    {
        public string Code { get; set; }
     
        public string Country { get; set; }

        [JsonPropertyName("year established")]
        [JsonProperty("year established")]
        public long? YearEstablished { get; set; }

        
        public string Domain { get; set; }

        [JsonPropertyName("iso code")]
        [JsonProperty("iso code")]
        public string IsoCode { get; set; }

        
        public string Description { get; set; }

    }
}
