﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Media.Imaging;
namespace WpfApp1
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        ImageResizer resizer;

        private void UploadButton_Click(object sender, RoutedEventArgs e)
        {
            var dialog = new Microsoft.Win32.OpenFileDialog();
            dialog.InitialDirectory = "D:\\test";
            if (dialog.ShowDialog() == true)
            {  
                resizer = new ImageResizer(new System.IO.FileStream(dialog.FileName,System.IO.FileMode.Open));
               
            } 
        }

        private void ResizeTo300x250_Click(object sender, RoutedEventArgs e)
        {
            previewbox.Source = resizer.Resize(300, 250);
        }

        private void ResizeTo300x600_Click(object sender, RoutedEventArgs e)
        {
            previewbox.Source = resizer.Resize(300, 600);
        }

        private void ResizeTo720x90_Click(object sender, RoutedEventArgs e)
        {
            previewbox.Source = resizer.Resize(720, 90);
        }
    }
}
